tinyMCE.addI18n('en.sliderpro', {
	menuTitle: 'Select a slider'
});